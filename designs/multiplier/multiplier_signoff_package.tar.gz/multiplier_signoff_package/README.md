# multiplier Signoff Package

- Workspace: /home/haiji/backend/multiplier/ws_0003
- Status: ok
- Mapped synthesis netlist is under `synthesis/`.
- Harden outputs are under `harden/`.
- Final physical resources are under `final/`.
